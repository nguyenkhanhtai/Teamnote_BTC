n, d = map(int, input().split())

polje = []

for i in range(d - 1):
    polje.append(0)

for i in range(n):
    polje.append(i + 1)

while (len(polje) % 7 != 0):
    polje.append(0)

ukras = "+" + 21 * "-" + "+"

print (ukras)

for i in range(len(polje) // 7):
    redak = ""

    redak += "|"

    for j in range(7):
        dan = polje[7 * i + j]

        if (dan == 0):
            redak += "..."
        elif (dan <= 9):
            redak += ".." + str(dan)
        else:
            redak += "." + str(dan)

    redak += "|"

    print(redak)

print(ukras)
