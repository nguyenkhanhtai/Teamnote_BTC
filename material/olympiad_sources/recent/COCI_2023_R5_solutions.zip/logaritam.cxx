#include <iostream>
#include <vector>
using namespace std;

int const K = 10005;
int lp[K];
vector<int> pr;

int main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

    pr.reserve(K/8);
    
    for (int i = 2; i < K; ++i) {
        if (lp[i] == 0) {
            lp[i] = i;
            pr.push_back(i);
        }
        for (int j = 0; (long long) i * pr[j] < K; ++j) {
            lp[i * pr[j]] = pr[j];
            if (pr[j] == lp[i]) break;
        }
    }
    long long n;
    int q;
    cin >> n >> q;
    while (q--) {
        long long x, mxp = 0;
        cin >> x;
        if (x == 1) {
            cout << "-1\n";
            continue;
        }
        for (auto p : pr) {
            while (x % p == 0) {
                mxp = max(mxp, 1ll * p);
                x /= p;
            }
            if (x == 1) break;
        }
        if (x > 1) mxp = max(mxp, x);
        cout << n / mxp - 1 << '\n';
    }

	return 0;
}

