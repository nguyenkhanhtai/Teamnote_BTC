X = int(input())
Y = int(input())
Z = int(input())

L = [X, Y, Z]

najmanji = L.index(min(L))
najveci = L.index(max(L))

print(X + Y + Z - max(L))

print(chr(65 + najmanji), chr(65 + najveci))

if najmanji == 0:
    if najveci == 1:
        drugi = 2
    else:
        drugi = 1
elif najmanji == 1:
    if najveci == 0:
        drugi = 2
    else:
        drugi = 0
elif najmanji == 2:
    if najveci == 0:
        drugi = 1
    else:
        drugi = 0

print(chr(65 + drugi), chr(65 + najveci))
