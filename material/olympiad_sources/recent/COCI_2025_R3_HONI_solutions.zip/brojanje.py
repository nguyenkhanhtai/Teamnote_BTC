x = int(input())
y = int(input())
n = int(input())

print(x + n * y)
print(x - n * y)
