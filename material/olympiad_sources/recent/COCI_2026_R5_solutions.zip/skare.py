n, k = map(int, input().split())
rez = [0] * n
for _ in range(k):
    x, l = map(int, input().split())
    j = 1
    br = 0
    while br < x - 1:
        if rez[j] == 1:
            br = br + 1
        j = j + 1
    rez[j + l - 1] = 1
duljine = [0] * (n + 1)
zadnji = 0
for i in range(1, n):
    if rez[i] == 1:
        duljine[i - zadnji] = 1
        zadnji = i
duljine[n - zadnji] = 1
br_raz = 0
for i in range(1, n + 1):
    if duljine[i] == 1:
        br_raz = br_raz + 1
print(br_raz)

