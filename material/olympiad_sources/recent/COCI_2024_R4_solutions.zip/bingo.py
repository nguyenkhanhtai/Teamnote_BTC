def check_bingo(board, numbers):
    for i in range(5):
        for j in range(5):
            if board[i][j] in numbers:
                board[i][j] = 0

    for i in range(5):
        if board[i][0] == board[i][1] == board[i][2] == board[i][3] == board[i][4] == 0:
            return True

    for i in range(5):
        if board[0][i] == board[1][i] == board[2][i] == board[3][i] == board[4][i] == 0:
            return True

    if board[0][0] == board[1][1] == board[2][2] == board[3][3] == board[4][4] == 0:
        return True

    if board[0][4] == board[1][3] == board[2][2] == board[3][1] == board[4][0] == 0:
        return True

    return False

n = int(input())

names = []
boards = []

for i in range(n):
    name = input()
    board = []
    for j in range(5):
        board.append(list(map(int, input().split())))

    names.append(name)
    boards.append(board)

m = int(input())
numbers = list(map(int, input().split()))

bingo = []

for i in range(n):
    if check_bingo(boards[i], numbers):
        bingo.append(names[i])

print(len(bingo))

for name in bingo:
    print(name)
