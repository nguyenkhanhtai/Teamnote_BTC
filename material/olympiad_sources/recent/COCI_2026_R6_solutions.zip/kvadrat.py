x = int(input())

print(x * x)
print(x * x * x)