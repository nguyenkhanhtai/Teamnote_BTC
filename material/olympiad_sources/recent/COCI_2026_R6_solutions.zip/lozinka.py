n = int(input())

if n <= 9:
    print(n)
if n > 9 and n <= 18:
    print((n - 9) * 11)
if n == 19:
    print(111)