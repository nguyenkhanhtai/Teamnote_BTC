a, b = map(int, input().split())

if a == b:
    print(0)
elif a < b or a % b == 0:
    print(1)
else:
    print(2)