n, m = map(int, input().split())
cokolada = []
for i in range(n):
    red = input()
    cokolada.append(red)

ukupno_rez = 0

for i in range(n - 1):
    rez = 0
    for j in range(m):
        if cokolada[i][j] != cokolada[i + 1][j]:
            rez = 1
    if rez == 1:
        ukupno_rez = ukupno_rez + 1

for j in range(m - 1):
    rez = 0
    for i in range(n):
        if cokolada[i][j] != cokolada[i][j + 1]:
            rez = 1
    if rez == 1:
        ukupno_rez = ukupno_rez + 1

print(ukupno_rez)