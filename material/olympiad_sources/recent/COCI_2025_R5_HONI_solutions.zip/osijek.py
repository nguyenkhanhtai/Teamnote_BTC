A = int(input())
B = int(input())
C = int(input())

if A + B + C >= 12:
	print("OCPC")
else:
	print(12 - A - B - C)
