n = int(input())

s = 0
for i in range(n):
	x = int(input())
	if i % 2 == 0:
		s -= x
	else:
		s += x

if n % 2 == 0:
	print(s)
else:
	print("UPALJENO")