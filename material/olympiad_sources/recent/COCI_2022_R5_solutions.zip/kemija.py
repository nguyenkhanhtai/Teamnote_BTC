def prebroj(s):
    molekule = s.split('+')
    rj = [0] * 26
    for mol in molekule:
        broj_molekula = 1
        if mol[0].isdigit():
            broj_molekula = int(mol[0])
            mol = mol[1:]

        for i in range(len(mol)):
            if mol[i].isdigit():
                continue

            broj_atoma = 1
            if i < len(mol) - 1:
                if mol[i + 1].isdigit():
                    broj_atoma = int(mol[i + 1])

            rj[ord(mol[i])-ord('A')] += broj_atoma * broj_molekula

    return rj


n = int(input())

for i in range(n):
    jed = input()
    lijevo, desno = jed.split("->")

    broj_l = prebroj(lijevo)
    broj_d = prebroj(desno)

    if broj_l == broj_d:
        print("DA")
    else:
        print("NE")
