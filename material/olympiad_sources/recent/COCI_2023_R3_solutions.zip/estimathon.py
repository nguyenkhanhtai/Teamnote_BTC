n, m = map(int, input().split())
l = list(map(int, input().split()))
broj = 0
p = 1
if m > n:
	print("NE")
else:
	for i in l:
		if i < 4:
			p = 0
		broj += i // 4
	if p == 0 or broj < n:
		print("NE")
	else:
		print("DA")
