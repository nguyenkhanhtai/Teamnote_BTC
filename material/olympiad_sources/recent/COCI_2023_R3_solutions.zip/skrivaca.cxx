#include <bits/stdc++.h>

using namespace std;

int const N = 1000009;
int n;
vector<int> v;
vector<vector<int>> adj;
vector<int> ans;

void load() {
    int m;
    cin >> n >> m;
    ans.resize(n, INT_MAX);
    v.resize(n);
    adj.resize(n);
    for (auto &it : v) cin >> it, --it;
    for (int i = 0; i < m; ++i) {
        int u, v;
        cin >> u >> v;
        --u; --v;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }
}

queue<pair<int, int>> q;
int tim[N], low[N];
int cnt = 1;


void dfsst(int ver, int par) {
    tim[ver] = low[ver] = cnt++;
    int rep = -2; //unassigned
    if (tim[v[ver]] != 0) rep = -1;
    vector<pair<int, int>> ranges;
    for (auto u : adj[ver]) if (u != par) {
        if (tim[u] == 0) {
            dfsst(u, ver);
            if (low[u] >= tim[ver]) {
                ranges.emplace_back(tim[u], cnt);
            }
            if (rep == -2 && tim[v[ver]] != 0) {
                if (low[u] >= tim[ver]) {
                    rep = ranges.size() - 1;
                } else rep = -1; // special
            }
            low[ver] = min(low[ver], low[u]);
        } else {
            low[ver] = min(low[ver], tim[u]);
        }
    }
    if (rep == -2) rep = -1;
    if (ranges.empty()) return;
    for (auto u : adj[ver]) {
        int comp = --upper_bound(begin(ranges), end(ranges), pair<int, int>{tim[v[u]], INT_MAX}) - begin(ranges);
        if (comp != -1 && ranges[comp].second <= tim[v[u]]) comp = -1;
        if (comp != rep) {
            if (ans[u] == INT_MAX) ans[u] = 1, q.emplace(u, 1);
        }
    }
}

void bfs() {
    while (!q.empty()) {
        auto [v, w] = q.front();
        q.pop();
        for (auto u : adj[v]) {
            if (ans[u] == INT_MAX) {
                ans[u] = w + 1;
                q.emplace(u, w + 1);
            }
        }
    }
}

void solve() {
    for (int i = 0; i < n; ++i) if (v[i] == i) ans[i] = 0, q.emplace(i, 0);
    for (int i = 0; i < n; ++i) {
        for (auto u : adj[i]) if (u == v[i] && ans[i] == INT_MAX) {
            q.emplace(i, 1);
            ans[i] = 1;
            break;
        }
    }
    dfsst(0, -1);
    bfs();
    if (ans[0] == INT_MAX) {
        for (int i = 0; i < n; ++i) {
            cout << "-1 ";
        }
        cout << '\n';
    } else {
        for (auto a : ans) {
            cout << a << ' ';
        }
        cout << '\n';
    }
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    load();
    solve();

    return 0;
}
