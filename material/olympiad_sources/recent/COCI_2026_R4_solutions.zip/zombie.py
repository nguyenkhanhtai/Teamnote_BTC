n, m, k = map(int, input().split())
x, r, t = [], [], []

for _ in range(k):
    xi, ri, ti = map(int, input().split())
    x.append(xi)
    r.append(ri)
    t.append(ti)

br = 0
for i in range(1, m + 1):
    prezivio = 1
    for j in range(k):
        lj = max(x[j] - r[j], 1)
        rj = min(x[j] + r[j], n)
        poz = t[j] - i + 1
        if poz >= lj and poz <= rj:
            prezivio = 0
    if prezivio == 1:
        br = br + 1;

print(br)

