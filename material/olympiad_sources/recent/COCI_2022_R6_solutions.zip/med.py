from functools import cmp_to_key

def cmp(x, y):
    if x[0] == y[0]:
        return [1, -1][x[1] < y[1]]
    return [-1, 1][x[0] < y[0]]

n = int(input())
m = []
for i in range(n):
    l = input().split()
    m.append([sum(map(int, l[1:])), l[0]])
for i in range(n):
    x = m[:]
    m[i][0]+=500
    x.sort(key=lambda x: x[1])
    x.sort(key=lambda x: x[0], reverse=True)
    print(x.index(m[i])+1, end=' ')

    y = m[:]
    m[i][0]-=2*500
    y.sort(key=lambda x: x[1])
    y.sort(key=lambda x: x[0], reverse=True)
    print(y.index(m[i])+1)
    m[i][0]+=500
