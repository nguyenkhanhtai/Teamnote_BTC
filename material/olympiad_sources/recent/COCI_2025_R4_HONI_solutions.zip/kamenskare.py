n = int(input())

magda = 0
stjepan = 0

for i in range(n):
	m, s = input().split()
	if m == s:
		continue # nerijeseno
	if m == 'K' and s == 'S':
		magda += 1
	elif m == 'S' and s == 'P':
		magda += 1
	elif m == 'P' and s == 'K':
		magda += 1
	else:
		stjepan += 1

if magda >= stjepan:
	print("Magda")
else:
	print("Stjepan")
