AG = int(input())
BG = int(input())
tko = int(input())
CG = int(input())

D = AG
K = BG

if tko == 1:
    print("DONALD")
    D += CG
else:
    print("KAMALA")
    K += CG

if D > K:
    print("DONALD")
else:
    print("KAMALA")
