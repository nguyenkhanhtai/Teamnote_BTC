n = int(input())

cijena = 0
brojac = 0

for i in range(n):
	x = int(input())
	brojac += 1
	if brojac == 5:
		brojac = 0
	else:
		cijena += x
		
print(cijena)