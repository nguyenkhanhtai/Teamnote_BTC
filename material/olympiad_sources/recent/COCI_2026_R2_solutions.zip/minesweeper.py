n, m, k = map(int, input().split())
px = [-1, -1, 0, 1, 1, 1, 0, -1]
py = [0, 1, 1, 1, 0, -1, -1, -1]
mat = []

for i in range(n):
    mat.append([0] * m)
    
for i in range(k):
    x, y = map(int, input().split())
    x -= 1
    y -= 1
    mat[x][y] = -1
    for j in range(8):
        nx = x + px[j]
        ny = y + py[j]
        if (nx >= 0 and ny >= 0 and nx < n and ny < m):
            if (mat[nx][ny] != -1):
                mat[nx][ny] += 1

for i in range(n):
    for j in range(m):
        if (mat[i][j] == -1):
            print("B", end = " ")
        else:
            print(mat[i][j], end = " ")
    print()
        
    
    
