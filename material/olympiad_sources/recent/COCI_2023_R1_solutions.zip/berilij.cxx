#include <bits/stdc++.h>
#define F first
#define S second

using namespace std;

int const N = 1e5 + 10;
using ld = long double;

ld const EPS = 1e-8;

int n, m;
vector<vector<pair<int, ld>>> adj;
vector<ld> ans;
vector<pair<int, ld>> pol;
bool bio[N];

ld dist(pair<ld, ld> x, pair<ld, ld> y) {
    return sqrt((x.F - y.F) * (x.F - y.F) + (x.S - y.S) * (x.S - y.S));
}

void load() {
    cin >> n >> m;
    adj.resize(n);
    pol.resize(n);
    ans.resize(n, -1);
    vector<pair<ld, ld>> points(n);
    for (auto &[a, b] : points) cin >> a >> b;
    for (int i = 0; i < m; ++i) {
        int u, v;
        cin >> u >> v;
        --u; --v;
        adj[u].emplace_back(v, dist(points[u], points[v]));
        adj[v].emplace_back(u, dist(points[u], points[v]));
    }
}

ld lb, ub;

pair<int, ld> getPoly(int ver, int par) {
    bio[ver] = true;
    if (pol[ver].F == 1) {
        lb = max(lb, -pol[ver].S);
    } else {
        ub = min(ub, pol[ver].S);
    }
    pair<int, ld> ret;
    if (pol[ver].F == 1) {
        ret = {1, pol[ver].S};
    } else ret = {1, -pol[ver].S};
    for (auto [u, w] : adj[ver]) if (u != par) {
        if (!bio[u]) {
            pol[u] = {-pol[ver].F, w - pol[ver].S};
            auto t = getPoly(u, ver);
            if (t.F <= 0) return t;
            ret.F += t.F;
            ret.S += t.S;
        } else {
            pair<int, ld> tmp = {-pol[ver].F, w - pol[ver].S};
            if (tmp.F == pol[u].F) {
                if (abs(tmp.S - pol[u].S) > EPS) {
                    //cerr << abs(tmp.S - pol[u].S) << ' ' << tmp.S << ' ' << pol[u].S << endl;
                    return {-1, 0};
                }
            } else {
                return {0, (pol[u].S * tmp.F + tmp.S * pol[u].F) / 2};
            }
        }
    }
    return ret;
}

bool check(int ver, int par, ld x) {
    if (x < -EPS) return false;
    bio[ver] = true;
    ans[ver] = x;
    for (auto [u, w] : adj[ver]) if (u != par) {
        if (ans[u] < -EPS) {
            if (!check(u, ver, w - x)) return false;
        } else {
            if (abs(ans[ver] + ans[u] - w) > EPS) {
                return false;
                //cerr << abs(ans[ver] + ans[u] - w) << endl;
            }
        }
    }
    return true;
}

void solve() {
    for (int i = 0; i < n; ++i) ans[i] = -1;
    for (int i = 0; i < n; ++i) if (!bio[i]) {
        lb = 0, ub = 1e12;
        pol[i] = {1, 0};
        
        auto val = getPoly(i, -1);
        //cerr << i << ' ' << val.F << ' ' << val.S << endl;
        if (val.F == -1) {
            //cerr << "NE1\n";
            cout << "NE\n";
            return;
        } else if (val.F == 0) {
            if (!check(i, -1, val.S)) {
                //cerr << "NE2\n";
                cout << "NE\n";
                return;
            }
        } else {
            if (ub - lb < -EPS) {
                //cerr << lb << ' ' << ub << endl;
                //cerr << "NE3\n";
                cout << "NE\n";
                return;
            }
            ld a = -val.S / val.F;
            a = max(lb, min(ub, a));
            if (!check(i, -1, a)) {
                //cerr << "NE4\n";
                cout << "NE\n";
                return;
            }
        }
    }
    cout << "DA\n";
    for (auto a : ans) {
        assert(a > -EPS);
        cout << abs(a) << '\n';
    }
    //cerr << lb << ' ' << ub << endl;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    //cerr << fixed << setprecision(12);
    //preciznost treba biti barem 8;
    cout << fixed << setprecision(6);
    load();
    solve();
    return 0;
}

