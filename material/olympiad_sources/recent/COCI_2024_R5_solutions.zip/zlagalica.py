n = int(input())
boja = [''] * 25
dim = [0] * 25
iza = [0] * 25
red = []

for i in range(1, n + 1):
    b, r, s, u, d = input().split()
    r, s, u, d = int(r), int(s), int(u), int(d)
    boja[i] = b
    dim[i] = (r, s)
    iza[i] = (u, d)

red = list(map(int, input().split()))

L = [[0] * 203 for _ in range(203)]

tr, ts, mr, ms = 201, 0, 201, 0

for ind in red:
    for i in range(tr, tr - dim[ind][0], -1):
        for j in range(ts, ts + dim[ind][1]):
            L[i][j] = ind

    mr = min(mr, tr - (dim[ind][0] - 1))
    ms = max(ms, ts + (dim[ind][1] - 1))

    if iza[ind][0] == 0:
        tr -= dim[ind][0]
        ts += (iza[ind][1] - 1)
    else:
        ts += dim[ind][1]
        tr -= (dim[ind][0] - iza[ind][1])

print(201 - mr + 1, ms + 1)

boja[0] = '.'
for i in range(mr, 202):
    for j in range(ms + 1):
        print(boja[L[i][j]], end='')
    print()
