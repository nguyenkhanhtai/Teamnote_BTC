cells = []

for row in range(9 + 4):
    line = input()

    if (row % 4 == 0):
        continue

    numbers = []

    for char in line:
        if (char.isdigit()):
            numbers.append(int(char))
        elif (char == "."):
            numbers.append(0)

    cells.append(numbers)

ok = True

for row in range(9):
    for number in range(1, 10):
        if (cells[row].count(number) > 1):
            ok = False
            break

if (ok):
    for col in range(9):
        for number in range(1, 10):
            count = 0

            for row in range(9):
                if (cells[row][col] == number):
                    count += 1

            if (count > 1):
                ok = False
                break

if (ok):
    for row in range(0, 9, 3):
        for col in range(0, 9, 3):
            for number in range(1, 10):
                count = 0

                for r in range(row, row + 3):
                    for c in range(col, col + 3):
                        if (cells[r][c] == number):
                            count += 1

                if (count > 1):
                    ok = False
                    break

if (ok):
    print("OK")
else:
    print("GRESKA")
