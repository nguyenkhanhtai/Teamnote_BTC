prvi = input()
drugi = input()
treci = input()

treci = treci.split('<')

while '' in treci:
    treci.remove('')

ime = treci[0].capitalize()
prezime = treci[1].capitalize()

oib = prvi[-15:-4]

godina = drugi[0:2]
mjesec = drugi[2:4]
dan = drugi[4:6]

if int(godina) <= 24:
    godina = "20" + godina
else:
    godina = "19" + godina

datum = dan + "-" + mjesec + "-" + godina

print("Ime:", ime)
print("Prezime:", prezime)
print("Datum rodjenja:", datum)
print("OIB:", oib)
