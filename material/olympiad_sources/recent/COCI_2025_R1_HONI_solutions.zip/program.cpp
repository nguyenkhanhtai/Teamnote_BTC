#include <iostream>

using namespace std;

int main() {
  int x, y;
  cin >> x >> y;

  cout << (y >= x ? "DA" : "NE") << '\n'; 

  return 0;
}
